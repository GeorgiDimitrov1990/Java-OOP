package collectionHierarchy;

public class AddCollection extends Collection implements Addable{


    @Override
    public int add(String string) {
        super.getItems().add(string);
        return super.getItems().indexOf(string);
    }
}
