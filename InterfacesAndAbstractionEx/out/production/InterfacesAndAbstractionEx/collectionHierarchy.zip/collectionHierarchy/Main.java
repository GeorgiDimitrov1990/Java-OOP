package collectionHierarchy;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] tokens = scanner.nextLine().split("\\s+");
        int num = Integer.parseInt(scanner.nextLine());
        AddCollection addCollection = new AddCollection();
        AddRemoveCollection addRemoveCollection = new AddRemoveCollection();
        MyListImpl myList = new MyListImpl();
        for (String token : tokens) {
            System.out.print(addCollection.add(token) + " ");
        }
        System.out.println();
        for (String token : tokens) {
            System.out.print(addRemoveCollection.add(token) + " ");
        }
        System.out.println();
        for (String token : tokens) {
            System.out.print(myList.add(token) + " ");
        }
        System.out.println();

        for (int i = 0; i < num; i++) {
            System.out.print(addRemoveCollection.remove() + " ");
        }
        System.out.println();
        for (int i = 0; i < num; i++) {
            System.out.print(myList.remove() + " ");
        }

    }
}
