package collectionHierarchy;

public class MyListImpl extends Collection implements MyList{
    @Override
    public int add(String string) {
        super.getItems().add(0, string);
        return 0;
    }

    @Override
    public String remove() {
        return super.getItems().remove(0);
    }

    @Override
    public int getUsed() {
        return super.getItems().size();
    }
}
