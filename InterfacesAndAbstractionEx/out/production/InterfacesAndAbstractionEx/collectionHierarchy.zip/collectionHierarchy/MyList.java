package collectionHierarchy;

public interface MyList extends AddRemovable{
    int getUsed();
}
