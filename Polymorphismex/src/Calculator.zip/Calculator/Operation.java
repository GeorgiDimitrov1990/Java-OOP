package Calculator;

public interface Operation {
    int operateWithNum(int firsNum, int secondNum);
    void operateWithMemory(int num);
    int secondNum();
}
